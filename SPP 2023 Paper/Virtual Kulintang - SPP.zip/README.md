# LaTeX-article-template
Current version for SPP2023 Siargao

This is a LaTeX template for full article submissions to the Proceedings of the Samahang Pisika ng Pilipinas.

Suggestions are welcome!
